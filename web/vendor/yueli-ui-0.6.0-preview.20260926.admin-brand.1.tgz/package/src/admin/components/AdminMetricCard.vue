<script setup lang="ts">
import { computed, resolveComponent } from "vue";
const props = withDefaults(defineProps<{
  label: string;
  value: string | number;
  detail?: string;
  icon: string;
  to?: string;
  tone?: "primary" | "success" | "warning" | "info" | "neutral";
}>(), { tone: "primary" });
const root = computed(() => props.to ? resolveComponent("NuxtLink") : "article");
const toneClass = computed(() => ({ primary: "text-primary", success: "text-success", warning: "text-warning", info: "text-info", neutral: "text-muted" })[props.tone]);
</script>

<template>
  <component :is="root" :to="to || undefined" data-admin-metric class="admin-metric" :class="toneClass">
    <span class="admin-metric-icon"><UIcon :name="icon" class="size-5" /></span>
    <dl class="min-w-0">
      <dt class="text-xs leading-5 text-muted">{{ label }}</dt>
      <dd class="mt-1 break-words text-2xl font-semibold leading-tight tracking-tight text-highlighted tabular-nums">{{ value }}</dd>
      <dd v-if="detail" class="mt-1 text-xs leading-5 text-dimmed">{{ detail }}</dd>
    </dl>
  </component>
</template>

<style scoped>
.admin-metric { display: grid; grid-template-columns: 2.5rem minmax(0, 1fr); gap: .75rem; min-width: 0; padding: 1rem; border: 1px solid var(--ui-border-muted); border-radius: .875rem; background: var(--ui-bg); transition: border-color 140ms; }
.admin-metric[href]:hover { border-color: color-mix(in srgb, var(--ui-primary) 35%, var(--ui-border)); }
.admin-metric[href]:focus-visible { outline: 2px solid var(--ui-primary); outline-offset: 3px; }
.admin-metric-icon { display: grid; place-items: center; width: 2.5rem; height: 2.5rem; border-radius: .75rem; background: color-mix(in srgb, currentColor 10%, transparent); }
@media (max-width: 639px) {
  .admin-metric { grid-template-columns: minmax(0, 1fr); padding: .875rem; gap: .5rem; }
  .admin-metric-icon { width: 2rem; height: 2rem; border-radius: .625rem; }
}
</style>
