<script setup lang="ts">
import { computed, ref } from "vue";
import type {
  AccountMenuAction,
  AccountMenuAppearance,
} from "../components/AccountMenu.vue";
export interface AccountMobilePanelMessages {
  currentUser: string;
  currentSite: string;
  role: string;
  siteFeatures: string;
  generalFeatures: string;
  logout: string;
  actionFailed: string;
}
export interface AccountMobileSite {
  label: string;
  role?: string;
  switchAction?: AccountMenuAction;
}
const props = withDefaults(
  defineProps<{
    name?: string;
    email?: string;
    avatarUrl?: string;
    site?: AccountMobileSite;
    contextActions?: readonly AccountMenuAction[];
    utilityActions?: readonly AccountMenuAction[];
    appearance?: AccountMenuAppearance;
    logout: () => unknown | Promise<unknown>;
    messages: AccountMobilePanelMessages;
  }>(),
  {
    name: "",
    email: "",
    avatarUrl: "",
    contextActions: () => [],
    utilityActions: () => [],
  },
);
const displayName = computed(
  () => props.name || props.email || props.messages.currentUser,
);
const busy = ref(false);
const failed = ref(false);
async function perform(callback: () => unknown | Promise<unknown>) {
  if (busy.value) return;
  busy.value = true;
  failed.value = false;
  try {
    await callback();
  } catch {
    failed.value = true;
  } finally {
    busy.value = false;
  }
}
async function select(action: AccountMenuAction, event: Event) {
  if (action.disabled || busy.value) {
    event.preventDefault();
    return;
  }
  if (action.onSelect) {
    event.preventDefault();
    await perform(() => action.onSelect?.(event));
  }
}
function changeAppearance(value: unknown) {
  if (value === "system" || value === "light" || value === "dark")
    void perform(() => props.appearance?.onChange(value));
}
const appearanceOptions = computed(() =>
  props.appearance
    ? [
        { label: props.appearance.messages.system, value: "system" },
        { label: props.appearance.messages.light, value: "light" },
        { label: props.appearance.messages.dark, value: "dark" },
      ]
    : [],
);
</script>
<template>
  <div class="account-mobile-panel">
    <section class="account-mobile-card" :aria-label="messages.currentUser">
      <div class="account-mobile-person">
        <UAvatar
          :src="avatarUrl || undefined"
          :text="displayName.charAt(0)"
          :alt="displayName"
          size="3xl"
        />
        <div class="min-w-0">
          <h1>{{ displayName }}</h1>
          <p v-if="email" class="account-mobile-email">{{ email }}</p>
        </div>
      </div>
      <div v-if="site" class="account-mobile-site">
        <span class="account-mobile-icon"
          ><UIcon name="i-tabler-server"
        /></span>
        <div class="min-w-0 flex-1">
          <p>
            {{ messages.currentSite }}<strong>{{ site.label }}</strong>
          </p>
          <p v-if="site.role" class="text-muted">
            {{ messages.role }}{{ site.role }}
          </p>
        </div>
        <UButton
          v-if="site.switchAction"
          :to="site.switchAction.to"
          :icon="site.switchAction.icon"
          color="primary"
          variant="soft"
          size="sm"
          :disabled="busy || site.switchAction.disabled"
          @click="select(site.switchAction, $event)"
          >{{ site.switchAction.label }}</UButton
        >
      </div>
    </section>
    <section
      v-if="contextActions.length"
      class="account-mobile-card"
      :aria-label="messages.siteFeatures"
    >
      <h2>{{ messages.siteFeatures }}</h2>
      <div class="account-mobile-rows">
        <UButton
          v-for="action in contextActions"
          :key="action.label"
          :to="action.to"
          color="neutral"
          variant="link"
          class="account-mobile-row"
          :disabled="busy || action.disabled"
          @click="select(action, $event)"
          ><span class="account-mobile-icon"
            ><UIcon :name="action.icon || 'i-tabler-apps'" /></span
          ><span class="account-mobile-copy"
            ><strong>{{ action.label }}</strong
            ><span v-if="action.description">{{
              action.description
            }}</span></span
          ><UIcon name="i-tabler-chevron-right" class="account-mobile-chevron"
        /></UButton>
      </div>
    </section>
    <section
      v-if="utilityActions.length || appearance"
      class="account-mobile-card"
      :aria-label="messages.generalFeatures"
    >
      <h2>{{ messages.generalFeatures }}</h2>
      <div class="account-mobile-rows">
        <UButton
          v-for="action in utilityActions"
          :key="action.label"
          :to="action.to"
          color="neutral"
          variant="link"
          class="account-mobile-row"
          :disabled="busy || action.disabled"
          @click="select(action, $event)"
          ><span class="account-mobile-icon"
            ><UIcon :name="action.icon || 'i-tabler-settings'" /></span
          ><span class="account-mobile-copy"
            ><strong>{{ action.label }}</strong
            ><span v-if="action.description">{{
              action.description
            }}</span></span
          ><UIcon name="i-tabler-chevron-right" class="account-mobile-chevron"
        /></UButton>
        <UCollapsible v-if="appearance"
          ><UButton color="neutral" variant="link" class="account-mobile-row"
            ><span class="account-mobile-icon"
              ><UIcon name="i-tabler-palette" /></span
            ><span class="account-mobile-copy"
              ><strong>{{ appearance.messages.label }}</strong
              ><span>{{
                appearanceOptions.find(
                  (option) => option.value === appearance?.value,
                )?.label
              }}</span></span
            ><UIcon
              name="i-tabler-chevron-down"
              class="account-mobile-chevron" /></UButton
          ><template #content
            ><URadioGroup
              :model-value="appearance.value"
              :items="appearanceOptions"
              :legend="appearance.messages.label"
              :disabled="busy"
              class="account-mobile-appearance"
              @update:model-value="changeAppearance" /></template
        ></UCollapsible>
      </div>
    </section>
    <UAlert v-if="failed" color="error" :description="messages.actionFailed" />
    <UButton
      color="error"
      variant="link"
      class="account-mobile-logout"
      :loading="busy"
      :disabled="busy"
      @click="perform(logout)"
      ><span class="account-mobile-icon"><UIcon name="i-tabler-logout" /></span
      ><span>{{ messages.logout }}</span
      ><UIcon name="i-tabler-chevron-right" class="ml-auto size-4"
    /></UButton>
  </div>
</template>
<style scoped>
.account-mobile-panel {
  display: grid;
  gap: 12px;
  max-width: 640px;
  margin-inline: auto;
}
.account-mobile-card {
  padding: 16px;
  border-radius: 14px;
  background: var(--ui-bg);
  box-shadow: 0 5px 20px rgb(24 68 82 / 4%);
}
.account-mobile-person {
  display: flex;
  align-items: center;
  gap: 14px;
}
.account-mobile-person h1 {
  color: var(--ui-text-highlighted);
  font-size: 22px;
  line-height: 1.4;
  font-weight: 650;
  overflow-wrap: anywhere;
}
.account-mobile-email {
  margin-top: 3px;
  color: var(--ui-text-muted);
  font-size: 13px;
  overflow-wrap: anywhere;
}
.account-mobile-site {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-top: 16px;
  padding-top: 14px;
  border-top: 1px solid var(--ui-border);
  font-size: 12px;
  line-height: 1.8;
}
.account-mobile-site strong {
  color: var(--ui-primary);
  font-weight: 600;
}
.account-mobile-card h2 {
  margin-bottom: 8px;
  font-size: 15px;
  font-weight: 650;
  color: var(--ui-text-highlighted);
}
.account-mobile-row {
  display: flex;
  width: 100%;
  gap: 12px;
  padding: 12px 0;
  text-align: start;
  text-decoration: none;
  white-space: normal;
  border-radius: 0;
}
.account-mobile-rows > :not(:first-child) {
  border-top: 1px solid var(--ui-border);
}
.account-mobile-icon {
  display: grid;
  place-items: center;
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  border-radius: 11px;
  background: color-mix(in srgb, var(--ui-primary) 9%, var(--ui-bg));
  color: var(--ui-primary);
}
.account-mobile-icon :deep(.iconify) {
  width: 23px;
  height: 23px;
}
.account-mobile-copy {
  display: grid;
  min-width: 0;
  gap: 3px;
  flex: 1;
}
.account-mobile-copy strong {
  font-size: 15px;
  color: var(--ui-text-highlighted);
  font-weight: 600;
}
.account-mobile-copy > span {
  font-size: 12px;
  font-weight: 400;
  color: var(--ui-text-muted);
  line-height: 1.5;
}
.account-mobile-chevron {
  width: 16px;
  height: 16px;
  color: var(--ui-text-muted);
  flex-shrink: 0;
}
.account-mobile-appearance {
  padding: 4px 0 14px 52px;
}
.account-mobile-logout {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  padding: 10px 16px;
  background: var(--ui-bg);
  border-radius: 14px;
  font-size: 15px;
}
.account-mobile-logout .account-mobile-icon {
  color: var(--ui-error);
  background: color-mix(in srgb, var(--ui-error) 7%, var(--ui-bg));
}
</style>
