<script setup lang="ts">
import { useActionFeedback, useMinimumLoading } from "@yueli/ui/feedback";
import {
  SettingSection,
  SettingsLayout,
  SettingsSaveDock,
} from "@yueli/ui/settings/pattern";
import { useVueSettingsWorkflow } from "@yueli/ui/settings/vue";
import { computed, nextTick, onMounted, reactive, ref, watch } from "vue";
import {
  INHERIT_ASSET_BACKEND,
  assetProfileGuides,
  assetSettingsSaveMessages,
  bytesToMegabytes,
  formatAssetBytes,
  megabytesToBytes,
  useAssetSettingsProtection,
  type AssetProfileGuide,
  type AssetProfileView,
  type AssetSiteView,
  type AssetStorageBackendView,
} from "../settings";

interface AssetProfileForm extends Omit<AssetProfileView, "maxSizeBytes"> {
  maxSizeMB: number;
}

interface AssetSettingsData {
  site: AssetSiteView | null;
  backends: AssetStorageBackendView[];
  profiles: AssetProfileView[];
}

const props = withDefaults(
  defineProps<{
    siteKey: string;
    siteName: string;
    description?: string;
    showHeader?: boolean;
    profileOrder?: string[];
    excludeProfiles?: string[];
    canManage?: boolean;
    permissionPending?: boolean;
    permissionDescription?: string;
    deliveryProfileKey?: string;
  }>(),
  {
    description:
      "配置当前站点使用资源中心时的默认存储、用途规则、文件限制与访问级别。",
    showHeader: true,
    profileOrder: () => [],
    excludeProfiles: () => [],
    canManage: true,
    permissionPending: false,
    permissionDescription: "当前账户没有管理站点资源策略的权限。",
    deliveryProfileKey: "",
  },
);

const { call } = useAssetAdminApi();
const toast = useToast();
const {
  status: saveStatus,
  pending: markSaving,
  success: markSaved,
  reset: resetSave,
} = useActionFeedback();
const saveError = ref("");
const permissionReady = computed(
  () => props.canManage && !props.permissionPending,
);

const emptyData = (): AssetSettingsData => ({
  site: null,
  backends: [],
  profiles: [],
});
const data = ref<AssetSettingsData>(emptyData());
const loadStatus = ref<"idle" | "pending" | "success" | "error">("idle");
const loadError = ref<Error | null>(null);
const mounted = ref(false);
let requestVersion = 0;

async function fetchSettings(): Promise<AssetSettingsData> {
  const [sites, backends, profiles] = await Promise.all([
    call<{ items: AssetSiteView[] }>("/api/v1/admin/assets/sites"),
    call<{ items: AssetStorageBackendView[] }>(
      "/api/v1/admin/assets/storage-backends",
    ),
    call<{ items: AssetProfileView[] }>("/api/v1/admin/assets/profiles", {
      query: { siteKey: props.siteKey },
    }),
  ]);
  const site =
    sites.items.find((item) => item.siteKey === props.siteKey) || null;
  const visibleProfiles = profiles.items.filter(
    (profile) => !props.excludeProfiles.includes(profile.profileKey),
  );
  if (!site)
    throw new Error(`${props.siteName}（${props.siteKey}）尚未初始化资源配置`);
  if (!backends.items.length) throw new Error("资源服务尚未配置存储后端");
  if (
    !site.defaultStorageBackend ||
    !backends.items.some(
      (backend) => backend.name === site.defaultStorageBackend,
    )
  ) {
    throw new Error(
      `站点默认存储后端 ${site.defaultStorageBackend || "未设置"} 不存在`,
    );
  }
  if (!visibleProfiles.length)
    throw new Error(`站点 ${props.siteKey} 尚未配置资源用途`);
  return { site, backends: backends.items, profiles: visibleProfiles };
}

const siteForm = reactive({
  name: "",
  defaultStorageBackend: "",
  enabled: false,
});
const profileForms = ref<AssetProfileForm[]>([]);
const expandedProfiles = ref<Record<string, boolean>>({});
const settingsState = useVueSettingsWorkflow({
  snapshot: () => ({ site: siteForm, profiles: profileForms.value }),
  restore: (snapshot) => {
    Object.assign(siteForm, snapshot.site);
    profileForms.value = snapshot.profiles;
  },
});
useAssetSettingsProtection(() => settingsState.dirty.value);

function profilePosition(key: string) {
  const index = props.profileOrder.indexOf(key);
  return index === -1 ? Number.MAX_SAFE_INTEGER : index;
}

watch(data, (value) => {
  if (!value.site) return;
  siteForm.name = value.site.name;
  siteForm.defaultStorageBackend = value.site.defaultStorageBackend;
  siteForm.enabled = value.site.enabled;
  profileForms.value = value.profiles
    .map((profile) => ({
      ...profile,
      storageBackend: profile.storageBackend || INHERIT_ASSET_BACKEND,
      maxSizeMB: bytesToMegabytes(profile.maxSizeBytes),
      metadataPolicy: profile.metadataPolicy || "strip",
    }))
    .sort(
      (a, b) =>
        profilePosition(a.profileKey) - profilePosition(b.profileKey) ||
        a.profileKey.localeCompare(b.profileKey),
    );
  nextTick(settingsState.capture);
});

async function reload() {
  if (!permissionReady.value) return;
  const version = ++requestVersion;
  saveError.value = "";
  loadError.value = null;
  loadStatus.value = "pending";
  try {
    const value = await fetchSettings();
    if (version !== requestVersion) return;
    data.value = value;
    loadStatus.value = "success";
  } catch (cause) {
    if (version !== requestVersion) return;
    loadError.value =
      cause instanceof Error ? cause : new Error("资源配置加载失败");
    loadStatus.value = "error";
  }
}

onMounted(() => {
  mounted.value = true;
  if (permissionReady.value) void reload();
});

watch(permissionReady, (ready) => {
  if (!mounted.value) return;
  if (ready) {
    void reload();
    return;
  }
  requestVersion += 1;
  data.value = emptyData();
  loadError.value = null;
  loadStatus.value = "idle";
});

const showSkeleton = useMinimumLoading(
  computed(
    () =>
      props.permissionPending ||
      (permissionReady.value &&
        (!mounted.value ||
          loadStatus.value === "idle" ||
          loadStatus.value === "pending")),
  ),
);
const backendItems = computed(() =>
  data.value.backends.map((backend) => ({
    label: `${backend.name}${backend.type ? ` · ${backend.type}` : ""}${backend.enabled ? "" : " · 已停用"}`,
    value: backend.name,
    disabled:
      !backend.enabled && backend.name !== siteForm.defaultStorageBackend,
  })),
);
const profileBackendItems = computed(() => [
  {
    label: `继承站点默认 · ${siteForm.defaultStorageBackend}`,
    value: INHERIT_ASSET_BACKEND,
    disabled: false,
  },
  ...backendItems.value,
]);
const selectedBackend = computed(
  () =>
    data.value.backends.find(
      (backend) => backend.name === siteForm.defaultStorageBackend,
    ) || null,
);
const accessLevelItems = [
  { label: "公开资源 · 公开直链", value: "public" },
  { label: "私有资源 · 签名链接", value: "private" },
];
const metadataPolicyItems = [
  { label: "移除隐私元数据并重写", value: "strip" },
  { label: "保留原始元数据（仅私有）", value: "preserve" },
];
const deliveryProfile = computed(() =>
  profileForms.value.find(
    (profile) => profile.profileKey === props.deliveryProfileKey,
  ),
);
const loadMessage = computed(
  () =>
    loadError.value?.message ||
    "资源配置加载失败，请检查资源服务与站点初始化状态。",
);

function backendStatus(backend: AssetStorageBackendView | null) {
  if (!backend)
    return {
      label: "后端不可用",
      color: "error" as const,
      icon: "i-tabler-alert-circle",
    };
  if (!backend.enabled)
    return {
      label: "后端已停用",
      color: "warning" as const,
      icon: "i-tabler-player-pause",
    };
  if (backend.healthy || backend.lastHealthOk)
    return {
      label: "运行正常",
      color: "success" as const,
      icon: "i-tabler-circle-check",
    };
  return {
    label: "健康检查异常",
    color: "error" as const,
    icon: "i-tabler-alert-circle",
  };
}

function profileGuide(profile: AssetProfileForm): AssetProfileGuide {
  return (
    assetProfileGuides[profile.profileKey] || {
      title: profile.profileKey,
      icon:
        profile.defaultVisibility === "private"
          ? "i-tabler-lock"
          : "i-tabler-folder-cog",
      description: profile.purpose || "按用途配置资源上传、存储和访问规则。",
      recommendation: "根据真实业务收紧文件后缀、大小与访问级别。",
    }
  );
}

function profileExpanded(profile: AssetProfileForm) {
  return expandedProfiles.value[profile.profileKey] === true;
}

function toggleProfile(profile: AssetProfileForm) {
  expandedProfiles.value = {
    ...expandedProfiles.value,
    [profile.profileKey]: !profileExpanded(profile),
  };
}

function profileStorageLabel(profile: AssetProfileForm) {
  return profile.storageBackend === INHERIT_ASSET_BACKEND
    ? `继承 ${siteForm.defaultStorageBackend}`
    : profile.storageBackend;
}

function profileBackend(profile: AssetProfileForm) {
  const name =
    profile.storageBackend === INHERIT_ASSET_BACKEND
      ? siteForm.defaultStorageBackend
      : profile.storageBackend;
  return data.value.backends.find((backend) => backend.name === name) || null;
}

function accessLevelLabel(profile: AssetProfileForm) {
  return profile.defaultVisibility === "private" ? "私有签名链接" : "公开直链";
}

function keepOriginalLabel(profile: AssetProfileForm) {
  return profile.keepOriginal ? "保留原始文件" : "只保留处理结果";
}

watch(
  profileForms,
  (profiles) => {
    for (const profile of profiles) {
      profile.defaultDeliveryPolicy =
        profile.defaultVisibility === "public" ? "public" : "signed";
      if (profile.defaultVisibility === "public") {
        profile.metadataPolicy = "strip";
      }
    }
  },
  { deep: true },
);

async function save() {
  if (!settingsState.dirty.value || !props.canManage) return;
  if (
    profileForms.value.some(
      (profile) => !Number.isFinite(profile.maxSizeMB) || profile.maxSizeMB < 0,
    )
  ) {
    saveError.value = "文件大小必须是大于或等于 0 的数字";
    return;
  }
  markSaving();
  saveError.value = "";
  try {
    await call("/api/v1/admin/assets/sites", {
      method: "POST",
      body: {
        siteKey: props.siteKey,
        name: siteForm.name.trim(),
        defaultStorageBackend: siteForm.defaultStorageBackend,
        enabled: siteForm.enabled,
      },
    });
    await Promise.all(
      profileForms.value.map((profile) =>
        call("/api/v1/admin/assets/profiles", {
          method: "POST",
          body: {
            siteKey: profile.siteKey,
            profileKey: profile.profileKey,
            purpose: profile.purpose,
            allowedExt: profile.allowedExt.trim(),
            maxSizeBytes: megabytesToBytes(profile.maxSizeMB),
            defaultVisibility: profile.defaultVisibility,
            defaultDeliveryPolicy:
              profile.defaultVisibility === "public" ? "public" : "signed",
            storageBackend:
              profile.storageBackend === INHERIT_ASSET_BACKEND
                ? ""
                : profile.storageBackend,
            keepOriginal: profile.keepOriginal,
            metadataPolicy: profile.metadataPolicy,
          },
        }),
      ),
    );
    markSaved();
    settingsState.capture();
  } catch (cause) {
    resetSave();
    saveError.value = (cause as Error).message || "资源配置保存失败";
    toast.add({
      title: "资源配置保存失败",
      description: saveError.value,
      color: "error",
    });
  }
}

function discardChanges() {
  settingsState.discard();
  saveError.value = "";
  resetSave();
}
</script>

<template>
  <SettingsLayout
    title="资源配置"
    :description="description"
    :show-header="showHeader"
    :show-section-navigation="false"
    navigation-label="设置分区"
  >
    <div
      v-if="showSkeleton"
      class="space-y-3"
      role="status"
      aria-label="正在加载资源设置"
    >
      <USkeleton v-for="row in 4" :key="row" class="h-20 rounded-lg" />
    </div>

    <UAlert
      v-else-if="!canManage"
      color="warning"
      variant="subtle"
      icon="i-tabler-shield-lock"
      title="没有资源配置权限"
      :description="permissionDescription"
    />

    <div
      v-else-if="loadError"
      class="space-y-3 rounded-lg border border-error/30 bg-error/5 p-4"
    >
      <UAlert
        color="error"
        variant="subtle"
        icon="i-tabler-alert-circle"
        title="资源配置不可用"
        :description="loadMessage"
      />
      <UButton
        icon="i-tabler-refresh"
        label="重新加载"
        color="neutral"
        variant="soft"
        @click="reload"
      />
    </div>

    <template v-else-if="data.site">
      <SettingSection
        title="站点资源策略"
        description="选择站点默认使用的存储后端，并控制当前站点是否允许消费资源服务。"
      >
        <div
          class="grid gap-4 sm:grid-cols-2 xl:grid-cols-[minmax(0,1fr)_minmax(14rem,1fr)_8rem]"
        >
          <UFormField label="站点名称" required>
            <UInput v-model="siteForm.name" class="w-full" />
          </UFormField>
          <UFormField label="默认存储后端" required>
            <USelectMenu
              v-model="siteForm.defaultStorageBackend"
              :items="backendItems"
              value-key="value"
              class="w-full"
            />
          </UFormField>
          <UFormField label="站点启用">
            <div class="flex min-h-8 items-center gap-3">
              <USwitch v-model="siteForm.enabled" />
              <span class="text-sm text-default">{{
                siteForm.enabled ? "已启用" : "已停用"
              }}</span>
            </div>
          </UFormField>
        </div>

        <div
          v-if="selectedBackend"
          class="mt-4 flex flex-col gap-3 rounded-lg border border-default bg-elevated/40 p-3 sm:flex-row sm:items-center sm:justify-between"
        >
          <div class="flex min-w-0 items-center gap-3">
            <span
              class="grid size-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"
            >
              <UIcon name="i-tabler-database" class="size-5" />
            </span>
            <div class="min-w-0">
              <p class="truncate text-sm font-medium text-highlighted">
                {{ selectedBackend.name }} ·
                {{ selectedBackend.type || "未标注类型" }}
              </p>
              <p class="mt-0.5 text-xs text-muted">
                素材 {{ selectedBackend.assetCount }} · 站点
                {{ selectedBackend.siteCount }} · 用途
                {{ selectedBackend.profileCount }}
              </p>
            </div>
          </div>
          <UBadge
            :label="backendStatus(selectedBackend).label"
            :color="backendStatus(selectedBackend).color"
            :icon="backendStatus(selectedBackend).icon"
            variant="soft"
          />
        </div>
        <p
          v-if="
            selectedBackend &&
            !(selectedBackend.healthy || selectedBackend.lastHealthOk)
          "
          class="mt-2 text-sm text-error"
        >
          {{
            selectedBackend.lastHealthError ||
            selectedBackend.error ||
            "存储后端最近一次健康检查未通过。"
          }}
        </p>
      </SettingSection>

      <SettingSection
        title="用途规则"
        description="每个 Profile 对应一种真实上传用途，可以覆盖后端并独立限制文件大小、后缀与访问级别。"
      >
        <div class="space-y-3">
          <article
            v-for="profile in profileForms"
            :key="profile.profileKey"
            class="overflow-hidden rounded-lg border border-default bg-default"
          >
            <div
              class="flex flex-col gap-4 p-4 xl:flex-row xl:items-start xl:justify-between"
            >
              <div class="flex min-w-0 items-start gap-3">
                <span
                  class="grid size-10 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"
                >
                  <UIcon :name="profileGuide(profile).icon" class="size-5" />
                </span>
                <div class="min-w-0">
                  <div class="flex flex-wrap items-center gap-2">
                    <h3 class="font-medium text-highlighted">
                      {{ profileGuide(profile).title }}
                    </h3>
                    <UBadge
                      :label="profile.profileKey"
                      color="neutral"
                      variant="soft"
                      size="sm"
                    />
                    <UBadge
                      :label="accessLevelLabel(profile)"
                      :color="
                        profile.defaultVisibility === 'private'
                          ? 'warning'
                          : 'success'
                      "
                      variant="soft"
                      size="sm"
                    />
                  </div>
                  <p class="mt-1 max-w-3xl text-sm leading-6 text-muted">
                    {{ profileGuide(profile).description }}
                  </p>
                  <div class="mt-3 flex flex-wrap gap-2 text-xs text-muted">
                    <span class="rounded-md bg-elevated px-2 py-1"
                      >后端：{{ profileStorageLabel(profile) }}</span
                    >
                    <span class="rounded-md bg-elevated px-2 py-1"
                      >上限：{{
                        formatAssetBytes(megabytesToBytes(profile.maxSizeMB))
                      }}</span
                    >
                    <span class="rounded-md bg-elevated px-2 py-1"
                      >后缀：{{ profile.allowedExt || "未限制" }}</span
                    >
                    <span class="rounded-md bg-elevated px-2 py-1">{{
                      keepOriginalLabel(profile)
                    }}</span>
                  </div>
                </div>
              </div>
              <UButton
                :icon="
                  profileExpanded(profile)
                    ? 'i-tabler-chevron-up'
                    : 'i-tabler-adjustments-horizontal'
                "
                :label="profileExpanded(profile) ? '收起' : '编辑配置'"
                color="neutral"
                variant="soft"
                size="sm"
                class="self-start"
                @click="toggleProfile(profile)"
              />
            </div>

            <div
              v-if="profileExpanded(profile)"
              class="border-t border-default bg-elevated/30 p-4"
            >
              <p class="mb-4 text-xs leading-5 text-muted">
                {{ profileGuide(profile).recommendation }}
              </p>
              <div class="grid gap-4 sm:grid-cols-2">
                <UFormField label="存储后端">
                  <USelectMenu
                    v-model="profile.storageBackend"
                    :items="profileBackendItems"
                    value-key="value"
                    class="w-full"
                  />
                </UFormField>
                <UFormField label="最大大小（MB）" help="填写 0 表示不限制。">
                  <UInput
                    v-model.number="profile.maxSizeMB"
                    type="number"
                    min="0"
                    step="0.1"
                    class="w-full"
                  />
                </UFormField>
                <UFormField
                  label="访问级别"
                  help="私有资源需要业务授权后生成签名链接。"
                >
                  <USelectMenu
                    v-model="profile.defaultVisibility"
                    :items="accessLevelItems"
                    value-key="value"
                    class="w-full"
                  />
                </UFormField>
                <UFormField
                  label="隐私元数据"
                  help="公开资源必须移除 EXIF/GPS；私有原件可显式保留。"
                >
                  <USelectMenu
                    v-model="profile.metadataPolicy"
                    :items="metadataPolicyItems"
                    value-key="value"
                    class="w-full"
                    :disabled="profile.defaultVisibility === 'public'"
                  />
                </UFormField>
                <UFormField label="原始文件策略">
                  <div class="flex min-h-8 items-center gap-3">
                    <USwitch v-model="profile.keepOriginal" />
                    <span class="text-sm text-default">{{
                      keepOriginalLabel(profile)
                    }}</span>
                  </div>
                </UFormField>
              </div>
              <UFormField
                class="mt-4"
                label="允许后缀"
                help="使用英文逗号分隔；留空表示不限制。"
              >
                <UInput
                  v-model="profile.allowedExt"
                  class="w-full"
                  placeholder="jpg,jpeg,png,webp"
                />
              </UFormField>
              <UAlert
                v-if="
                  profileBackend(profile) &&
                  !(
                    profileBackend(profile)?.healthy ||
                    profileBackend(profile)?.lastHealthOk
                  )
                "
                class="mt-4"
                color="warning"
                variant="subtle"
                icon="i-tabler-alert-triangle"
                title="当前用途选择的存储后端不可用"
                :description="
                  profileBackend(profile)?.lastHealthError ||
                  profileBackend(profile)?.error ||
                  '请先修复后端健康状态再上传资源。'
                "
              />
            </div>
          </article>
        </div>
      </SettingSection>

      <UAlert
        v-if="deliveryProfile"
        color="warning"
        variant="subtle"
        icon="i-tabler-cloud-upload"
        title="大文件交付建议"
        :description="`当前直传上限为 ${formatAssetBytes(megabytesToBytes(deliveryProfile.maxSizeMB))}。超过后应使用支持分片的对象存储或网盘交付。`"
      />
    </template>

    <div
      v-else
      class="space-y-3 rounded-lg border border-error/30 bg-error/5 p-4"
    >
      <UAlert
        color="error"
        variant="subtle"
        icon="i-tabler-alert-circle"
        title="资源配置未返回数据"
        description="当前权限已经确认，但资源服务没有返回站点配置。请重新加载；仍失败时检查站点 provision。"
      />
      <UButton
        icon="i-tabler-refresh"
        label="重新加载"
        color="neutral"
        variant="soft"
        @click="reload"
      />
    </div>

    <SettingsSaveDock
      :dirty="settingsState.dirty.value"
      :status="saveStatus"
      :error="saveError"
      :disabled="!canManage"
      :messages="assetSettingsSaveMessages"
      dock-class="lg:left-60"
      @discard="discardChanges"
      @save="save"
    />
  </SettingsLayout>
</template>
