import {
  createError,
  defineEventHandler,
  getRequestHeader,
  getRequestURL,
  getRequestWebStream,
  getRouterParam,
  sendProxy,
} from "h3";

const UPLOAD_HEADER_ALLOWLIST = [
  "content-length",
  "content-md5",
  "content-type",
  "x-amz-checksum-sha256",
  "x-amz-content-sha256",
  "x-cos-meta-md5",
  "x-goog-hash",
  "x-oss-hash-crc64ecma",
] as const;

// Blob PUTs can be gigabytes. The general BFF deliberately buffers and caps
// JSON/form bodies; this exact signed route streams bytes without browser
// credentials and lets Asset validate the token, size, mime, and checksum.
export default defineEventHandler(async (event) => {
  const token = getRouterParam(event, "token");
  if (!token) {
    throw createError({ statusCode: 400, statusMessage: "Missing upload token" });
  }

  const runtime = useRuntimeConfig(event);
  const target = assetBffTarget(String(runtime.assetBase));
  const requestURL = getRequestURL(event);
  const targetURL = new URL(
    `${target.pathPrefix || ""}/api/v1/assets/blob/${encodeURIComponent(token)}${requestURL.search}`,
    target.origin,
  );
  const headers = new Headers();
  for (const name of UPLOAD_HEADER_ALLOWLIST) {
    const value = getRequestHeader(event, name);
    if (value) headers.set(name, value);
  }

  return await sendProxy(event, targetURL.toString(), {
    fetchOptions: {
      body: getRequestWebStream(event),
      duplex: "half",
      headers,
      method: "PUT",
      signal: AbortSignal.timeout(15 * 60 * 1000),
    },
    sendStream: true,
  });
});
