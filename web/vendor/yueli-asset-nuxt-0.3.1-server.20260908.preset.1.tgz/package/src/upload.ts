const ASSET_BLOB_PATH = "/api/v1/assets/blob/";

// Bounded, consumer-instance-local memo. Compare real bytes so reselecting a
// file works without trusting names/mtime, and without a secure-context hash API.
export function createAssetUploadMemo<T>() {
  const entries: Array<{ file: File, value: T }> = []
  let queue: Promise<unknown> = Promise.resolve()
  async function equal(a: File, b: File) {
    if (a === b) return true
    if (a.size !== b.size || a.type !== b.type) return false
    for (let offset = 0; offset < a.size; offset += 1024 * 1024) {
      const [left, right] = await Promise.all([a.slice(offset, offset + 1024 * 1024).arrayBuffer(), b.slice(offset, offset + 1024 * 1024).arrayBuffer()])
      const x = new Uint8Array(left), y = new Uint8Array(right)
      for (let i = 0; i < x.length; i++) if (x[i] !== y[i]) return false
    }
    return true
  }
  return {
    get(file: File, create: () => T): Promise<T> {
      const result = queue.then(async () => {
        for (const entry of entries) if (await equal(entry.file, file)) return entry.value
        const value = create()
        entries.unshift({ file, value })
        if (entries.length > 4) entries.pop()
        return value
      })
      queue = result.then(() => undefined, () => undefined)
      return result
    },
  }
}

export interface AssetImageTransferState {
  stage: 'uploading' | 'finalizing' | 'preparing' | 'error'
  progress?: number
  message?: string
}

/** Keep the editor from inserting a URL before its cold rendition is usable. */
export async function waitForAssetImage(url: string, signal?: AbortSignal): Promise<void> {
  for (let attempt = 0; attempt < 3; attempt++) {
    signal?.throwIfAborted()
    try {
      const requestSignal = signal
        ? AbortSignal.any([signal, AbortSignal.timeout(65_000)])
        : AbortSignal.timeout(65_000)
      const response = await fetch(url, { signal: requestSignal })
      if (!response.ok) {
        // A missing/forbidden or invalid asset is not a slow rendition.
        if (response.status >= 400 && response.status < 500 && response.status !== 408 && response.status !== 429) {
          throw new TypeError('图片暂不可用，请检查资源权限或图片处理限制。')
        }
        throw new Error('图片仍在处理，请稍后重试。')
      }
      const blob = await response.blob()
      if (!blob.type.startsWith('image/')) throw new TypeError('资源服务没有返回有效图片。')
      const objectURL = URL.createObjectURL(blob)
      try {
        const preview = new Image()
        preview.src = objectURL
        await preview.decode()
      } finally { URL.revokeObjectURL(objectURL) }
      signal?.throwIfAborted()
      return
    } catch (error) {
      signal?.throwIfAborted()
      if (error instanceof TypeError || attempt === 2) throw new Error(error instanceof TypeError ? error.message : '图片处理尚未完成或加载失败，可重试，无需重新上传。')
      await new Promise<void>((resolve, reject) => {
        const abort = () => { clearTimeout(timer); reject(signal?.reason) }
        const timer = setTimeout(() => { signal?.removeEventListener('abort', abort); resolve() }, 1000 * (attempt + 1))
        signal?.addEventListener('abort', abort, { once: true })
      })
    }
  }
}

function normalizeProxyBase(value: string): string {
  const trimmed = value.trim();
  if (!trimmed.startsWith("/") || trimmed.startsWith("//")) {
    throw new TypeError("Asset proxy base must be a root-relative path");
  }
  return trimmed.replace(/\/+$/, "");
}

/**
 * Routes Asset-owned blob URLs through the consumer site's same-origin BFF.
 * External object-storage presigned URLs are returned unchanged.
 */
export function assetUploadURL(
  value: string,
  proxyBase = "/asset-api",
): string {
  const raw = value.trim();
  if (!raw) throw new TypeError("Asset upload URL is required");

  const mount = normalizeProxyBase(proxyBase);
  const parsed = new URL(raw, "http://asset.invalid");
  const path = `${parsed.pathname}${parsed.search}`;

  if (parsed.pathname === mount || parsed.pathname.startsWith(`${mount}/`)) {
    return path;
  }
  if (parsed.pathname.startsWith(ASSET_BLOB_PATH)) {
    return `${mount}${path}`;
  }
  return raw;
}
