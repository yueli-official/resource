# @yueli/asset-nuxt

公开图片只通过 `assetMediaUrl(assetId, rendition)` 生成命名媒体 URL；消费者不得拼接 Asset UUID、尺寸、裁剪、
质量或内部派生路径。默认同站点地址为：

```text
/media/{mediaKey}?format=webp&name=display&v=1
```

该路径由匿名媒体代理转发给 Asset `/api/v1/media/*`；`v` 是必填缓存代际，派生规则变化时递增。`/asset-api` 继续只承载上传、管理等真正 API。生产环境
可通过 `base` 指向专用图片域名；query 始终按 `format`、`name` 的 canonical 顺序输出。以后新增 Asset v2 时
由代理选择 implementation 版本，浏览器 URL 不随之变化。

Asset 所有的 Nuxt 客户端层，提供同源 Asset/Identity BFF、标准 API composable、站点资源设置界面与图片裁剪器。
它不处理文件字节，也不拥有业务条目；资源元数据、存储和交付策略仍由 Asset 服务负责。

## 边界

- BFF 使用 `@yueli/nuxt-runtime` 的有界 handler，并从 `@yueli/identity-nuxt` 取得服务端会话凭证。
- composable 直接组合 Foundation HTTP/Nuxt runtime，不依赖产品自定义 `useApi`。
- 设置工作流与裁剪器组合 Foundation UI 的 settings、feedback 和 image 原语，不依赖 Platform Manage/UI。
- 产品拥有 site/profile 选择、业务授权和上传完成后的领域引用。标准资源策略页布局由 `AssetPolicyPage` 拥有。

## 使用

```ts
export default defineNuxtConfig({
  extends: ["@yueli/identity-nuxt", "@yueli/asset-nuxt"],
});
```

管理后台直接使用领域页面 Module：

```vue
<AssetPolicyPage
  expected-namespace="gallery"
  :profile-order="['gallery-submission']"
  :can-edit="canEditAssets"
/>
```

消费端必须配置名为 `asset` 与 `identity` 的 Yueli runtime target，并提供私有
`NUXT_ASSET_BASE`、`NUXT_IDENTITY_BASE`。大文件应使用 Asset 的签名直传/分片协议，不经过有界 BFF body。

## 验证

```text
pnpm --filter @yueli/asset-nuxt test
```
