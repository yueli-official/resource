// Sniff bytes, not the extension: all GIFs bypass the still-image canvas.
// Static GIFs are harmless here and are converted by the normal Asset rendition.
export async function preserveImageTimeline(file: Blob): Promise<boolean> {
  const bytes = new Uint8Array(await file.slice(0, 32).arrayBuffer())
  const ascii = (start: number, end: number) => String.fromCharCode(...bytes.slice(start, end))
  if (ascii(0, 6) === 'GIF89a' || ascii(0, 6) === 'GIF87a') return true
  return bytes.length >= 21 && ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP'
    && ascii(12, 16) === 'VP8X' && (bytes[20]! & 2) !== 0
}
