const assetAdminPrefix = "/api/v1/admin/assets";

export function toAssetAdminProxyPath(url: string) {
  const [rawPath, query] = url.split("?");
  const path = rawPath || "";
  if (path !== assetAdminPrefix && !path.startsWith(`${assetAdminPrefix}/`))
    throw new Error(`Unsupported asset admin path: ${path}`);
  const suffix = path.slice(assetAdminPrefix.length) || "/stats";
  return `/api/v1/admin/assets-proxy${suffix}${query ? `?${query}` : ""}`;
}
