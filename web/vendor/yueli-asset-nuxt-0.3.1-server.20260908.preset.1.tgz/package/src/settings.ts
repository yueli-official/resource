import { onMounted, onScopeDispose } from "vue";
import { bindSettingsBeforeUnload } from "@yueli/ui/settings/browser";
import type { SettingsSaveDockMessages } from "@yueli/ui/settings/pattern";
import { useSettingsLeaveGuard } from "@yueli/ui/settings/vue-router";

export const INHERIT_ASSET_BACKEND = "__inherit__";

export const assetSettingsSaveMessages: SettingsSaveDockMessages = {
  region: "资源设置保存操作",
  unsaved: "有未保存的资源设置",
  saving: "正在保存资源设置",
  saved: "资源设置已保存",
  failed: "资源设置保存失败",
  discard: "放弃",
  save: "保存",
  savePending: "保存中",
  saveSuccess: "已保存",
};

export function useAssetSettingsProtection(isDirty: () => boolean) {
  let unbindBeforeUnload: (() => void) | undefined;
  onMounted(() => {
    unbindBeforeUnload = bindSettingsBeforeUnload({ isDirty });
  });
  onScopeDispose(() => unbindBeforeUnload?.());
  useSettingsLeaveGuard({
    isDirty,
    confirm: () => window.confirm("有未保存的资源设置，确定离开当前页面吗？"),
  });
}

export interface AssetSiteView {
  siteKey: string;
  name: string;
  defaultStorageBackend: string;
  enabled: boolean;
  assetCount: number;
  profileCount: number;
  variantCount: number;
}

export interface AssetStorageBackendView {
  name: string;
  type?: string;
  enabled: boolean;
  managed: boolean;
  isDefault: boolean;
  healthy: boolean;
  assetCount: number;
  siteCount: number;
  profileCount: number;
  error?: string;
  lastHealthOk?: boolean;
  lastHealthError?: string;
  lastHealthCheckedAt?: string;
}

export interface AssetProfileView {
  siteKey: string;
  profileKey: string;
  purpose: string;
  storageBackend: string;
  allowedExt: string;
  maxSizeBytes: number;
  defaultVisibility: string;
  defaultDeliveryPolicy: string;
  keepOriginal: boolean;
  metadataPolicy: "strip" | "preserve";
  assetCount: number;
  variantCount: number;
}

export interface AssetProfileGuide {
  title: string;
  icon: string;
  description: string;
  recommendation: string;
}

export const assetProfileGuides: Record<string, AssetProfileGuide> = {
  "blog-cover": {
    title: "文章封面",
    icon: "i-tabler-photo",
    description: "用于文章列表、详情页首屏和分享预览，应保持为公开图片。",
    recommendation: "建议仅允许网页图片格式，控制在 10 MB 内并保留原图，方便重新裁剪和生成分享图。",
  },
  "blog-post": {
    title: "正文图片",
    icon: "i-tabler-file-description",
    description: "用于文章正文和图集，应提供稳定的公开访问地址。",
    recommendation: "建议仅允许网页图片格式，控制在 20 MB 内，并通过派生尺寸减少正文流量。",
  },
  "docs-collection-cover": {
    title: "文档集封面",
    icon: "i-tabler-photo",
    description: "用于文档集列表、入口卡片和分享预览，应保持为公开图片。",
    recommendation: "建议仅允许 jpg、jpeg、png、webp，控制在 10 MB 内并保留原图。",
  },
  "docs-import-image": {
    title: "文档正文图片",
    icon: "i-tabler-file-description",
    description: "用于 Markdown 导入和文档正文中的图片，应提供稳定的公开地址。",
    recommendation: "建议仅允许网页图片格式，控制在 20 MB 内，并统一生成适合正文宽度的派生图。",
  },
  attachment: {
    title: "文档附件",
    icon: "i-tabler-paperclip",
    description: "用于文档附带的 PDF 或压缩包，默认应通过签名链接访问。",
    recommendation: "建议保持私有访问，并按实际文档业务收紧后缀和文件大小。",
  },
  "shop-product-cover": {
    title: "商品头图",
    icon: "i-tabler-photo",
    description: "用于商品列表、详情页首屏和分享预览，应保持为公开图片。",
    recommendation: "建议仅允许网页图片格式，控制在 20 MB 内，默认走公开后端或 CDN。",
  },
  "shop-product-content": {
    title: "商品内容图片",
    icon: "i-tabler-file-description",
    description: "用于商品详情正文、说明和展示图集，应提供稳定的公开地址。",
    recommendation: "建议保留原图并生成展示尺寸，避免商品正文引用私有资源。",
  },
  "shop-product-delivery": {
    title: "下载资源",
    icon: "i-tabler-package",
    description: "用于支付后的文件交付，默认应为私有资源；购买与交付规则由商城业务负责。",
    recommendation: "小文件可直传；大文件应使用支持分片的 OSS、COS、S3 后端或网盘交付。",
  },
  "resource-cover": {
    title: "资源封面",
    icon: "i-tabler-photo",
    description: "用于资源卡片、详情页首图和分享预览，应保持为公开图片。",
    recommendation: "建议仅允许网页图片格式，控制在 10–20 MB 内，并保留原图以便重新裁剪。",
  },
  "resource-content": {
    title: "正文图片",
    icon: "i-tabler-file-description",
    description: "用于资源详情正文和展示图集，应提供稳定的公开地址。",
    recommendation: "建议仅允许网页图片格式并生成展示尺寸，避免正文引用私有资源。",
  },
  resource: {
    title: "下载文件",
    icon: "i-tabler-package",
    description: "用于资源站下载文件；登录、会员与积分门禁由资源站业务负责。",
    recommendation: "小文件可直传；大文件建议使用支持分片的对象存储或网盘，不建议长期走本地存储。",
  },
};

export function bytesToMegabytes(bytes: number): number {
  if (!Number.isFinite(bytes) || bytes <= 0) return 0;
  return Number((bytes / 1024 / 1024).toFixed(2));
}

export function megabytesToBytes(megabytes: number): number {
  if (!Number.isFinite(megabytes) || megabytes <= 0) return 0;
  return Math.round(megabytes * 1024 * 1024);
}

export function formatAssetBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return "不限制";
  const units = ["B", "KB", "MB", "GB"];
  let size = bytes;
  let unit = 0;
  while (size >= 1024 && unit < units.length - 1) {
    size /= 1024;
    unit += 1;
  }
  return `${size >= 10 || unit === 0 ? Math.round(size) : size.toFixed(1)} ${units[unit]}`;
}
