<script setup lang="ts">
import AdminTabs, {
  type AdminTabItem,
} from "../../admin/components/AdminTabs.vue";

const active = defineModel<string>({ required: true });
defineProps<{
  items: readonly AdminTabItem[];
  navigationLabel: string;
}>();
</script>

<template>
  <section
    class="yueli-card min-w-0 overflow-hidden"
    data-manage-tabbed-surface
  >
    <AdminTabs
      v-model="active"
      :items="items"
      :navigation-label="navigationLabel"
      class="border-b border-default sm:px-5"
    />
    <slot />
  </section>
</template>
