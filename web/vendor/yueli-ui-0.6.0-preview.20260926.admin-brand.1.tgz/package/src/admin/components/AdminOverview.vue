<template>
  <div class="admin-overview" data-admin-overview>
    <div class="admin-overview-content"><slot /></div>
    <div v-if="$slots.artwork" class="admin-overview-artwork" data-admin-overview-artwork aria-hidden="true">
      <slot name="artwork" />
    </div>
  </div>
</template>

<style scoped>
.admin-overview { position: relative; container: admin-overview / inline-size; min-width: 0; }
.admin-overview-content { min-width: 0; }
.admin-overview-artwork { display: none; pointer-events: none; }
@container admin-overview (min-width: 60rem) {
  .admin-overview-content:has(+ .admin-overview-artwork) { padding-inline-end: 14rem; }
  .admin-overview-artwork { position: absolute; inset-inline-end: 0; top: 50%; transform: translateY(-50%); display: grid; place-items: center; width: 13rem; height: 9rem; color: var(--ui-primary); }
  .admin-overview-artwork :deep(svg), .admin-overview-artwork :deep(img) { width: 100%; height: 100%; object-fit: contain; }
}
</style>
