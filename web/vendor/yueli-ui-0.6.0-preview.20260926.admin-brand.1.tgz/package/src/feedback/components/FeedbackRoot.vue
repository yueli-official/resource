<script setup lang="ts">
import { computed, onBeforeUnmount } from "vue";
import { provideFeedbackConfirm, type FeedbackConfirmTone } from "../confirm";
import FeedbackToastRegion from "./FeedbackToastRegion.client.vue";

const props = defineProps<{
  messages: {
    readonly confirm: string;
    readonly cancel: string;
    readonly toastClose: string;
  };
}>();

const controller = provideFeedbackConfirm();
const request = computed(() => controller.state.request);
const tone = computed<FeedbackConfirmTone>(
  () => request.value?.tone ?? "primary",
);
const confirmLabel = computed(
  () => request.value?.confirmLabel ?? props.messages.confirm,
);
const cancelLabel = computed(
  () => request.value?.cancelLabel ?? props.messages.cancel,
);
const confirmDisabled = computed(() =>
  Boolean(
    request.value?.input?.required && !controller.state.inputValue.trim(),
  ),
);

function updateOpen(open: boolean) {
  if (!open && controller.state.open) controller.cancel();
}

onBeforeUnmount(controller.dispose);
</script>

<template>
  <slot :confirm="controller.confirm" />
  <FeedbackToastRegion :close-label="messages.toastClose" />
  <UModal
    :open="controller.state.open"
    :title="request?.title ?? ''"
    :ui="{ content: 'max-w-md', footer: 'justify-end' }"
    @update:open="updateOpen"
  >
    <template #body>
      <div class="grid gap-3">
        <p v-if="request?.description" class="text-sm leading-6 text-muted">
          {{ request.description }}
        </p>
        <UFormField v-if="request?.input" :label="request.input.label">
          <UInput
            :model-value="controller.state.inputValue"
            :placeholder="request.input.placeholder"
            autofocus
            class="w-full"
            @update:model-value="controller.setInputValue(String($event ?? ''))"
            @keyup.enter="controller.accept"
          />
        </UFormField>
      </div>
    </template>
    <template #footer>
      <UButton
        :label="cancelLabel"
        color="neutral"
        variant="outline"
        @click="controller.cancel"
      />
      <UButton
        :label="confirmLabel"
        :color="tone"
        :disabled="confirmDisabled"
        @click="controller.accept"
      />
    </template>
  </UModal>
</template>
