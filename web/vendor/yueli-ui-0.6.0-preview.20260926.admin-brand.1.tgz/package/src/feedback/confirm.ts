import {
  inject,
  provide,
  reactive,
  type InjectionKey,
  type UnwrapNestedRefs,
} from "vue";

export type FeedbackConfirmTone = "primary" | "neutral" | "warning" | "error";

export interface FeedbackConfirmTextInput {
  readonly defaultValue?: string;
  readonly label?: string;
  readonly placeholder?: string;
  readonly required?: boolean;
}

export interface FeedbackConfirmOptions {
  readonly title: string;
  readonly description?: string;
  readonly tone?: FeedbackConfirmTone;
  readonly confirmLabel?: string;
  readonly cancelLabel?: string;
  readonly input?: FeedbackConfirmTextInput;
}

export interface FeedbackConfirmResult {
  readonly confirmed: boolean;
  readonly value?: string;
}

interface FeedbackConfirmState {
  open: boolean;
  request: FeedbackConfirmOptions | null;
  inputValue: string;
}

export interface FeedbackConfirmController {
  readonly state: UnwrapNestedRefs<FeedbackConfirmState>;
  confirm(options: FeedbackConfirmOptions): Promise<FeedbackConfirmResult>;
  accept(): void;
  cancel(): void;
  setInputValue(value: string): void;
  dispose(): void;
}

const feedbackConfirmKey: InjectionKey<FeedbackConfirmController> = Symbol(
  "yueli-feedback-confirm",
);

export function createFeedbackConfirmController(): FeedbackConfirmController {
  const state = reactive<FeedbackConfirmState>({
    open: false,
    request: null,
    inputValue: "",
  });
  let resolveActive: ((result: FeedbackConfirmResult) => void) | undefined;

  function settle(result: FeedbackConfirmResult) {
    const resolve = resolveActive;
    resolveActive = undefined;
    state.open = false;
    state.request = null;
    state.inputValue = "";
    resolve?.(result);
  }

  function confirm(options: FeedbackConfirmOptions) {
    if (resolveActive) settle({ confirmed: false });
    state.request = options;
    state.inputValue = options.input?.defaultValue ?? "";
    state.open = true;
    return new Promise<FeedbackConfirmResult>((resolve) => {
      resolveActive = resolve;
    });
  }

  function accept() {
    const input = state.request?.input;
    if (input?.required && !state.inputValue.trim()) return;
    settle({
      confirmed: true,
      ...(input ? { value: state.inputValue } : {}),
    });
  }

  function cancel() {
    settle({ confirmed: false });
  }

  function setInputValue(value: string) {
    state.inputValue = value;
  }

  return { state, confirm, accept, cancel, setInputValue, dispose: cancel };
}

export function provideFeedbackConfirm(
  controller: FeedbackConfirmController = createFeedbackConfirmController(),
) {
  provide(feedbackConfirmKey, controller);
  return controller;
}

export function useFeedbackConfirm(): FeedbackConfirmController {
  const controller = inject(feedbackConfirmKey);
  if (!controller) {
    throw new Error(
      "useFeedbackConfirm requires YFeedbackRoot above the caller",
    );
  }
  return controller;
}
