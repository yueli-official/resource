<script setup lang="ts">
const props = defineProps<{ totalPages: number; compact?: boolean }>();
const page = defineModel<number>({ required: true });
function go(value: number) {
  if (value >= 1 && value <= props.totalPages) page.value = value;
}
</script>

<template>
  <UPagination
    v-if="compact || totalPages > 1"
    :page="page"
    :total="Math.max(1, totalPages)"
    :items-per-page="1"
    :show-edges="compact"
    :ui="compact ? { first: '!inline-flex', last: '!inline-flex', list: 'flex-wrap' } : undefined"
    :data-compact-page-buttons="compact || undefined"
    :sibling-count="1"
    size="xs"
    @update:page="go"
  />
</template>

<style scoped>
[data-compact-page-buttons] :deep(button) {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 1.75rem;
  height: 1.75rem;
  min-width: 1.75rem;
  min-height: 1.75rem;
  padding: 0;
}
</style>
