<script setup lang="ts">
withDefaults(
  defineProps<{
    title: string;
    icon?: string;
    description?: string;
    headingId?: string;
    size?: "default" | "compact";
  }>(),
  { size: "default" },
);
</script>

<template>
  <header
    class="flex flex-wrap items-start justify-between gap-4 sm:items-center sm:gap-6"
    data-manage-page-header
    :data-has-tools="!!$slots.tools"
    :data-has-actions="!!$slots.actions"
  >
    <div class="flex min-w-0 items-center gap-3.5">
      <span
        v-if="icon"
        class="grid size-[var(--yueli-page-icon-size,2.5rem)] shrink-0 place-items-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/20 sm:size-[var(--yueli-page-icon-size,2.75rem)]"
        data-manage-page-icon
      >
        <UIcon :name="icon" class="size-5" />
      </span>
      <div class="min-w-0">
        <div v-if="$slots.eyebrow" class="mb-2"><slot name="eyebrow" /></div>
        <h1
          :id="headingId"
          class="font-display font-semibold tracking-[-0.025em] text-highlighted"
          :class="
            size === 'compact'
              ? 'text-[length:var(--yueli-page-heading-size,1.25rem)] leading-[var(--yueli-page-heading-leading,1.75rem)] sm:text-[length:var(--yueli-page-heading-size,1.5rem)] sm:leading-[var(--yueli-page-heading-leading,2rem)]'
              : 'text-[length:var(--yueli-page-heading-size,1.5rem)] leading-[var(--yueli-page-heading-leading,2rem)] sm:text-[length:var(--yueli-page-heading-size,1.875rem)] sm:leading-[var(--yueli-page-heading-leading,2.25rem)]'
          "
        >
          {{ title }}
        </h1>
        <div v-if="$slots.subtitle" class="mt-1 text-sm leading-6 text-muted">
          <slot name="subtitle" />
        </div>
        <p
          v-else-if="description"
          class="mt-1 max-w-3xl text-sm leading-6 text-muted"
        >
          {{ description }}
        </p>
      </div>
    </div>
    <div v-if="$slots.tools" class="min-w-0" data-manage-page-tools><slot name="tools" /></div>
    <div
      v-if="$slots.actions"
      class="flex shrink-0 flex-wrap items-center gap-2"
      data-manage-page-actions
    >
      <slot name="actions" />
    </div>
  </header>
</template>

<style scoped>
[data-manage-page-actions]:empty { display: none; }
[data-has-tools="true"] { display: grid; grid-template-columns: minmax(0,1fr); align-items: center; }
[data-has-tools="true"]:has(> [data-manage-page-actions] > *) { grid-template-columns: minmax(0,1fr) auto; }
[data-has-tools="true"] > [data-manage-page-actions] { grid-column: 2; grid-row: 1; justify-self: end; }
[data-manage-page-tools] { grid-column: 1 / -1; grid-row: 2; }
@media (min-width: 1280px) {
  [data-has-tools="true"] { grid-template-columns: auto minmax(0,1fr); }
  [data-has-tools="true"]:has(> [data-manage-page-actions] > *) { grid-template-columns: auto minmax(0,1fr) auto; }
  [data-manage-page-tools] { grid-column: 2; grid-row: 1; justify-self: end; width: min(100%, 42rem); }
  [data-has-tools="true"] > [data-manage-page-actions] { grid-column: 3; }
}
</style>
