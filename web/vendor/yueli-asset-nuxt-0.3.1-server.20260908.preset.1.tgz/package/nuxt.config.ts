// Shared asset-plane BFF and typed envelope clients.
export default defineNuxtConfig({
  runtimeConfig: {
    assetBase: "",
    assetAudience: "asset-api",
    identityBase: "",
  },
});
