<script setup lang="ts">
import { computed } from "vue";
export interface FacetEditorValue {
  name: string;
  slug: string;
  description: string;
  status: string;
  minValues: number;
  maxValues: number;
  maxDepth: number;
  leafOnly: boolean;
  parentId: string;
}
const props = withDefaults(
  defineProps<{
    modelValue: FacetEditorValue;
    kind: "dimension" | "value" | "numeric";
    resourceLabel?: string;
    parentOptions?: { label: string; value: string }[];
  }>(),
  { resourceLabel: "条目", parentOptions: () => [] },
);
const emit = defineEmits<{ "update:modelValue": [value: FacetEditorValue] }>();
function field<K extends keyof FacetEditorValue>(key: K) {
  return computed({
    get: () => props.modelValue[key],
    set: (value: FacetEditorValue[K]) =>
      emit("update:modelValue", { ...props.modelValue, [key]: value }),
  });
}
const name = field("name"),
  slug = field("slug"),
  description = field("description"),
  status = field("status"),
  minValues = field("minValues"),
  maxValues = field("maxValues"),
  maxDepth = field("maxDepth"),
  leafOnly = field("leafOnly"),
  parentId = field("parentId");
const statuses = [
  { label: "公开", value: "active" },
  { label: "停用", value: "inactive" },
];
const depths = [
  { label: "不限制", value: 0 },
  ...Array.from({ length: 12 }, (_, i) => ({
    label: `${i + 1} 级`,
    value: i + 1,
  })),
];
</script>
<template>
  <div class="grid gap-5">
    <div class="grid grid-cols-2 gap-4 max-sm:grid-cols-1">
      <UFormField label="名称" required
        ><UInput
          v-model="name"
          :maxlength="80"
          autofocus
          class="w-full" /></UFormField
      ><UFormField label="标识（Slug）" help="留空时根据名称自动生成。"
        ><UInput v-model="slug" :maxlength="80" class="w-full"
      /></UFormField>
    </div>
    <UFormField label="说明"
      ><UTextarea
        v-model="description"
        :rows="2"
        :maxlength="240"
        class="w-full"
    /></UFormField>
    <slot name="icon" />
    <section class="grid gap-4 border-t border-default pt-4">
      <h3
        v-if="kind === 'dimension'"
        class="text-sm font-semibold text-highlighted"
      >
        目录与选择规则
      </h3>
      <div class="grid grid-cols-2 gap-4 max-sm:grid-cols-1">
        <UFormField label="公开状态"
          ><USelect
            v-model="status"
            :items="statuses"
            value-key="value"
            aria-label="公开状态"
            class="w-full"
        /></UFormField>
        <template v-if="kind === 'dimension'">
          <UFormField label="目录层级上限"
            ><USelect
              v-model="maxDepth"
              :items="depths"
              value-key="value"
              aria-label="目录层级上限"
              class="w-full"
          /></UFormField>
          <UFormField
            :label="`每条${resourceLabel}至少选择`"
            help="0 表示可以不选。"
            ><UInputNumber
              v-model="minValues"
              :min="0"
              :max="100"
              :aria-label="`每条${resourceLabel}至少选择`"
              class="w-full"
          /></UFormField>
          <UFormField
            :label="`每条${resourceLabel}最多选择`"
            help="0 表示不限数量。"
            ><UInputNumber
              v-model="maxValues"
              :min="0"
              :max="100"
              :aria-label="`每条${resourceLabel}最多选择`"
              class="w-full"
          /></UFormField>
        </template>
        <UFormField v-else-if="kind === 'value'" label="父级"
          ><USelectMenu
            v-model="parentId"
            :items="parentOptions"
            value-key="value"
            aria-label="父级"
            class="w-full"
        /></UFormField>
      </div>
      <UFormField
        v-if="kind === 'dimension'"
        label="只允许选择末级项"
        help="父级负责组织和浏览，不直接分配给条目。"
        ><USwitch v-model="leafOnly" aria-label="只允许选择末级项"
      /></UFormField>
      <p
        v-if="kind === 'dimension' && maxValues > 0 && minValues > maxValues"
        role="alert"
        class="text-xs text-error"
      >
        最少选择数量不能超过最多选择数量。
      </p>
    </section>
  </div>
</template>
