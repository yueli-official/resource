import { adminModule } from "./projection";
import type {
  AdminAccessRequirement,
  AdminModuleDefinition,
} from "./types";

export interface AdminSoftwareCommerceBinding {
  readonly distribution: {
    readonly softwareSlug: string;
  };
  readonly commerce: {
    readonly siteKey: string;
  };
}

export interface AdminSoftwareCommerceModuleOptions {
  readonly id?: string;
  readonly label?: string;
  readonly icon?: string;
  readonly access?: AdminAccessRequirement;
  readonly distribution: {
    readonly to: string;
    readonly access?: AdminAccessRequirement;
    readonly label?: string;
    readonly icon?: string;
  };
  readonly commerce: {
    readonly to: string;
    readonly access?: AdminAccessRequirement;
    readonly label?: string;
    readonly icon?: string;
  };
}

function fixedIdentifier(value: string, field: string): string {
  if (!value || value.trim() !== value || /\s/u.test(value)) {
    throw new Error(`admin platform: ${field} must be a fixed identifier`);
  }
  return value;
}

/**
 * Declares the product-owned identities used by Distribution and Commerce.
 *
 * These values belong in product adapter code/config. Shared UI can consume the
 * binding, but must never expose either identifier as an editable admin field.
 */
export function defineAdminSoftwareCommerceBinding<
  T extends AdminSoftwareCommerceBinding,
>(binding: T): T {
  fixedIdentifier(binding.distribution.softwareSlug, "distribution software slug");
  fixedIdentifier(binding.commerce.siteKey, "commerce site key");
  return binding;
}

/**
 * Stable navigation/workflow shape for products that administer software
 * releases through Distribution and commercial policy through Commerce.
 *
 * The product owns routes, capabilities, transport and DTO mapping. This
 * helper deliberately does not know provider URLs, credentials or product
 * identifiers.
 */
export function softwareCommerceAdminModule(
  options: AdminSoftwareCommerceModuleOptions,
): AdminModuleDefinition {
  return adminModule({
    id: options.id || "software-commerce",
    label: options.label || "发行与商业",
    icon: options.icon || "i-tabler-package-export",
    access: options.access,
    children: [
      {
        id: "distribution",
        label: options.distribution.label || "软件发行",
        icon: options.distribution.icon || "i-tabler-packages",
        to: options.distribution.to,
        access: options.distribution.access,
      },
      {
        id: "commerce",
        label: options.commerce.label || "商业策略",
        icon: options.commerce.icon || "i-tabler-currency-yuan",
        to: options.commerce.to,
        access: options.commerce.access,
      },
    ],
  });
}
