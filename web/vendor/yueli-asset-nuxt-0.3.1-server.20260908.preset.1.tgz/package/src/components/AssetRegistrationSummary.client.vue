<script setup lang="ts">
import { computed, onMounted, ref } from "vue";
import {
  formatRegistrationBytes,
  registrationKindLabel,
  type AssetConsumerSettingsUpdateResponse,
  type AssetRegistrationApplicationView,
  type AssetRegistrationProfile,
  type AssetRegistrationResponse,
  type AssetRegistrationStateView,
  type AssetRegistrationVariant,
  type AssetVariantPresetOption,
  type AssetVariantSlotDefinition,
  type AssetProfileStorageBackendOptions,
} from "../registration";

interface EditableProfile {
  key: string;
  maxBytes: number;
  variants: AssetRegistrationVariant[];
  kind: AssetRegistrationProfile["kind"];
  purpose: string;
  visibility: AssetRegistrationProfile["visibility"];
  storageClass: string;
  storageBackend: string;
  allowedMimes: string[];
  metadataPolicy: AssetRegistrationProfile["metadataPolicy"];
  keepOriginal: boolean;
  maxSizeMB: number;
}

type EditableVariant = EditableProfile["variants"][number];

const props = withDefaults(
  defineProps<{
    expectedNamespace?: string;
    profileOrder?: string[];
    canEdit?: boolean;
    variantSlots?: AssetVariantSlotDefinition[];
  }>(),
  { expectedNamespace: "", profileOrder: () => [], canEdit: false, variantSlots: () => [] },
);

const { call } = useAssetRuntimeApi("asset");
const status = ref<"pending" | "success" | "error">("pending");
const errorMessage = ref("");
const state = ref<AssetRegistrationStateView | null>(null);
const storageBackends = ref<AssetProfileStorageBackendOptions[]>([]);
const editing = ref(false);
const draftProfiles = ref<EditableProfile[]>([]);
const activeProfileKey = ref("");
const saveStatus = ref<"idle" | "saving" | "saved" | "submitted">("idle");
const saveError = ref("");

const registration = computed(() => state.value?.registration || null);
const latestApplication = computed<AssetRegistrationApplicationView | null>(() =>
  [...(state.value?.applications || [])].sort((left, right) => right.revision - left.revision)[0] || null,
);
const hasPendingChange = computed(() => latestApplication.value?.status === "pending");
const requestedProfiles = computed(() => {
  const requested = latestApplication.value?.declaration.profiles;
  if (!requested?.length) return registration.value?.effective.profiles || [];
  return requested.map((profile) => ({
    ...profile,
    storageBackend: profile.selectedStorageBackend || registration.value?.effective.profiles
      .find((effective) => effective.key === profile.key)?.storageBackend,
  }));
});
const profiles = computed(() => sortedProfiles(registration.value?.effective.profiles || requestedProfiles.value));
const activeProfile = computed(() =>
  draftProfiles.value.find((profile) => profile.key === activeProfileKey.value) || draftProfiles.value[0] || null,
);
const profileTabs = computed(() => draftProfiles.value.map((profile) => ({
  label: profile.purpose,
  value: profile.key,
  icon: profileIcon(profile),
  badge: profile.variants.length,
})));
const modeOptions = [
  { label: "填充裁剪", value: "fill" },
  { label: "等比缩放", value: "resize" },
  { label: "按宽度缩放", value: "resize-width" },
];

function sortedProfiles(values: AssetRegistrationProfile[]) {
  return [...values].sort((left, right) => {
    const leftIndex = props.profileOrder.indexOf(left.key);
    const rightIndex = props.profileOrder.indexOf(right.key);
    const leftPosition = leftIndex === -1 ? Number.MAX_SAFE_INTEGER : leftIndex;
    const rightPosition = rightIndex === -1 ? Number.MAX_SAFE_INTEGER : rightIndex;
    return leftPosition - rightPosition || left.key.localeCompare(right.key);
  });
}

async function load() {
  status.value = "pending";
  errorMessage.value = "";
  try {
    const result = await call<AssetRegistrationResponse>("/api/v1/assets/registration");
    assertExpectedNamespace(result.state);
    state.value = result.state;
    storageBackends.value = result.storageBackends || [];
    status.value = "success";
  } catch (error) {
    errorMessage.value = error instanceof Error ? error.message : "资源注册状态加载失败";
    status.value = "error";
  }
}

function assertExpectedNamespace(value: AssetRegistrationStateView) {
  const namespace = value.registration?.namespaceKey ||
    [...value.applications].sort((left, right) => right.revision - left.revision)[0]?.declaration.namespaceKey;
  if (props.expectedNamespace && namespace !== props.expectedNamespace) {
    throw new Error("当前站点绑定到了其他资源空间");
  }
}

function beginEdit() {
  draftProfiles.value = sortedProfiles(requestedProfiles.value).map((profile) => ({
    key: profile.key,
    kind: profile.kind,
    purpose: profile.purpose,
    visibility: profile.visibility,
    storageClass: profile.storageClass,
    storageBackend: profile.selectedStorageBackend || profile.storageBackend || "",
    allowedMimes: [...profile.allowedMimes],
    maxBytes: profile.maxBytes,
    maxSizeMB: Number((profile.maxBytes / 1024 / 1024).toFixed(1)),
    metadataPolicy: profile.metadataPolicy,
    keepOriginal: profile.keepOriginal,
    variants: profile.variants.map((variant) => ({
      ...variant,
      presets: (variant.presets || []).map((preset) => ({ ...preset })),
    })),
  }));
  activeProfileKey.value = draftProfiles.value[0]?.key || "";
  saveError.value = "";
  saveStatus.value = "idle";
  editing.value = true;
}

function cancelEdit() {
  editing.value = false;
  saveError.value = "";
  saveStatus.value = "idle";
}

function validateDraft() {
  for (const profile of draftProfiles.value) {
    if (!Number.isFinite(profile.maxSizeMB) || profile.maxSizeMB <= 0) return `${profile.purpose}的大小上限必须大于 0`;
    if (!profile.storageBackend) return `${profile.purpose}必须选择存储后端`;
    if (!storageBackendItems(profile.key).some((item) => item.value === profile.storageBackend && !item.disabled)) {
      return `${profile.purpose}选择的存储后端不可用`;
    }
    for (const variant of profile.variants) {
      if (variant.presets.length && !selectedPreset(profile.key, variant)) {
        return `${profile.purpose}的 ${variantDisplayName(profile.key, variant.key)} 未选择有效预设`;
      }
      if (variant.width <= 0 || variant.height <= 0 || variant.quality < 1 || variant.quality > 100) {
        return `${profile.purpose}的派生规格数值无效`;
      }
    }
  }
  return "";
}

function slotDefinition(profileKey: string, variantKey: string) {
  return props.variantSlots.find((slot) => slot.profileKey === profileKey && slot.key === variantKey);
}

function variantDisplayName(profileKey: string, variantKey: string) {
  return slotDefinition(profileKey, variantKey)?.label || variantKey;
}

function variantUsage(profileKey: string, variantKey: string) {
  return slotDefinition(profileKey, variantKey)?.usage || "由产品代码调用";
}

function presetMatches(variant: EditableVariant, preset: AssetVariantPresetOption) {
  return variant.width === preset.width && variant.height === preset.height &&
    variant.mode === preset.mode && variant.format === preset.format && variant.quality === preset.quality;
}

function selectedPreset(profileKey: string, variant: EditableVariant) {
  return variant.presets.find((preset) => presetMatches(variant, preset))?.key || "";
}

function presetItems(profileKey: string, variant: EditableVariant) {
  const labels = slotDefinition(profileKey, variant.key)?.presetLabels || {};
  return variant.presets.map((preset) => ({
    label: labels[preset.key] || preset.key,
    value: preset.key,
  }));
}

function applyPreset(_profileKey: string, variant: EditableVariant, value: string | number) {
  const preset = variant.presets.find((item) => item.key === value);
  if (!preset) return;
  variant.width = preset.width;
  variant.height = preset.height;
  variant.mode = preset.mode;
  variant.format = preset.format;
  variant.quality = preset.quality;
}

function variantModeLabel(mode: string) {
  return modeOptions.find((option) => option.value === mode)?.label || mode;
}

function storageBackendTypeLabel(type: string) {
  return ({
    local: "本地存储",
    cos: "腾讯云 COS",
    s3: "S3 兼容存储",
    r2: "Cloudflare R2",
    minio: "MinIO",
    custom: "自定义存储",
  } as Record<string, string>)[type] || "对象存储";
}

function storageBackendItems(profileKey: string) {
  const configured = storageBackends.value.find((item) => item.profileKey === profileKey)?.items || [];
  if (configured.length) {
    return configured.map((backend) => ({
      label: `${storageBackendTypeLabel(backend.type)} · ${backend.name}`,
      value: backend.name,
      disabled: !backend.available,
    }));
  }
  const current = profiles.value.find((profile) => profile.key === profileKey)?.storageBackend;
  return current ? [{ label: current, value: current, disabled: false }] : [];
}

function storageBackendLabel(profile: Pick<AssetRegistrationProfile, "key" | "storageBackend">) {
  return storageBackendItems(profile.key).find((item) => item.value === profile.storageBackend)?.label || profile.storageBackend || "未配置存储";
}

function variantSizeLabel(variant: Pick<AssetRegistrationVariant, "width" | "height" | "mode">) {
  if (variant.mode === "resize-width") return `最大宽度 ${variant.width}px`;
  if (variant.mode === "resize" && variant.width === variant.height) return `最长边 ${variant.width}px`;
  if (variant.mode === "resize") return `不超过 ${variant.width}×${variant.height}`;
  return `${variant.width} × ${variant.height}`;
}

async function save() {
  const validation = validateDraft();
  if (validation) {
    saveError.value = validation;
    return;
  }
  saveStatus.value = "saving";
  saveError.value = "";
  try {
    const result = await call<AssetConsumerSettingsUpdateResponse>("/api/v1/assets/registration", {
      method: "PUT",
      body: {
        profiles: draftProfiles.value.map((profile) => ({
          key: profile.key,
          maxBytes: Math.round(profile.maxSizeMB * 1024 * 1024),
          storageBackend: profile.storageBackend,
          variants: profile.variants.map((variant) => ({
            key: variant.key,
            preset: selectedPreset(profile.key, variant),
          })),
        })),
      },
    });
    assertExpectedNamespace(result.state);
    state.value = result.state;
    storageBackends.value = result.storageBackends || storageBackends.value;
    saveStatus.value = result.application.status === "accepted" ? "saved" : "submitted";
    editing.value = false;
  } catch (error) {
    saveStatus.value = "idle";
    saveError.value = error instanceof Error ? error.message : "资源设置保存失败";
  }
}

function isImageProfile(profile: Pick<AssetRegistrationProfile, "kind">) {
  return profile.kind === "public-image" || profile.kind === "private-original";
}

function profileIcon(profile: Pick<AssetRegistrationProfile, "kind">) {
  if (profile.kind === "public-image") return "i-tabler-photo";
  if (profile.kind === "private-original") return "i-tabler-photo-shield";
  if (profile.kind === "private-file") return "i-tabler-file-lock";
  return "i-tabler-file";
}

function mimeLabel(values: string[]) {
  return values.map((value) => value.split("/").at(-1)?.toUpperCase() || value).join(" · ");
}

onMounted(load);
</script>

<template>
  <div class="min-w-0 max-w-full" data-asset-registration-summary>
    <div v-if="status === 'pending'" class="space-y-3">
      <USkeleton class="h-28 w-full rounded-xl" />
      <USkeleton class="h-40 w-full rounded-xl" />
    </div>

    <div v-else-if="status === 'error'" class="space-y-3">
      <UAlert color="error" variant="subtle" icon="i-tabler-alert-circle" title="资源注册不可用" :description="errorMessage" />
      <UButton label="重新加载" icon="i-tabler-refresh" color="neutral" variant="soft" @click="load" />
    </div>

    <div v-else-if="state" class="space-y-5">
      <section class="yueli-card p-4 sm:p-5" data-manage-surface="asset">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div class="min-w-0">
            <h2 class="text-sm font-semibold text-highlighted">资源注册</h2>
            <div class="mt-4 flex flex-wrap items-center gap-2">
              <p class="font-medium text-highlighted">
                {{ registration?.effective.displayName || latestApplication?.declaration.displayName || state.consumerKey }}
              </p>
              <UBadge
                :label="hasPendingChange ? (registration ? '有待处理变更' : '等待注册') : '已接受'"
                :color="hasPendingChange ? 'warning' : 'success'"
                variant="soft"
              />
            </div>
            <p class="mt-1 text-sm text-muted">
              资源空间 {{ registration?.namespaceKey || latestApplication?.declaration.namespaceKey }}
            </p>
          </div>
          <div class="flex flex-wrap items-center justify-end gap-2">
            <span v-if="saveStatus === 'saved'" class="text-sm text-success" aria-live="polite">已保存</span>
            <span v-else-if="saveStatus === 'submitted'" class="text-sm text-warning" aria-live="polite">已提交申请</span>
            <template v-if="editing">
              <UButton label="取消" color="neutral" variant="ghost" :disabled="saveStatus === 'saving'" @click="cancelEdit" />
              <UButton
                type="button"
                data-asset-registration-save
                icon="i-tabler-device-floppy"
                :label="saveStatus === 'saving' ? '保存中' : '保存'"
                :loading="saveStatus === 'saving'"
                @click="save"
              />
            </template>
            <UButton
              v-else-if="canEdit"
              data-asset-registration-edit
              label="编辑策略"
              icon="i-tabler-adjustments"
              color="neutral"
              variant="outline"
              @click="beginEdit"
            />
          </div>
        </div>
      </section>

      <UAlert
        v-if="saveError"
        color="error"
        variant="subtle"
        icon="i-tabler-alert-circle"
        title="资源设置未保存"
        :description="saveError"
      />

      <section v-if="!editing" class="yueli-card px-4 sm:px-5" data-manage-surface="asset">
        <div class="border-b border-default py-4">
          <h2 class="text-sm font-semibold text-highlighted">{{ registration ? '有效用途' : '申请用途' }}</h2>
        </div>
        <div class="divide-y divide-default">
          <article v-for="profile in profiles" :key="profile.key" class="py-5" :data-asset-profile-summary="profile.key">
            <div class="flex min-w-0 gap-3">
              <span class="grid size-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                <UIcon :name="profileIcon(profile)" class="size-5" />
              </span>
              <div class="min-w-0 flex-1">
                <div class="flex flex-wrap items-baseline gap-x-2 gap-y-1">
                  <h3 class="font-semibold text-highlighted">{{ profile.purpose }}</h3>
                  <span class="text-xs text-muted">{{ profile.key }}</span>
                </div>
                <p class="mt-1 text-sm text-muted">
                  {{ registrationKindLabel(profile.kind) }} · {{ formatRegistrationBytes(profile.maxBytes) }}
                  · {{ storageBackendLabel(profile) }} · {{ profile.keepOriginal ? '保留处理后源文件' : '仅保留派生文件' }}
                </p>
                <p class="mt-1 text-xs text-muted">{{ mimeLabel(profile.allowedMimes) }}</p>
              </div>
            </div>

            <div v-if="profile.variants.length" class="mt-4 divide-y divide-default border-y border-default">
              <div
                v-for="variant in profile.variants"
                :key="variant.key"
                class="flex min-w-0 items-center gap-4 py-2.5 text-sm"
                data-asset-variant-summary
              >
                <div class="min-w-0 flex-1">
                  <span class="font-medium text-default">{{ variantDisplayName(profile.key, variant.key) }}</span>
                  <span class="ml-1.5 text-xs text-muted">· {{ variant.key }}</span>
                  <span class="ml-2 hidden text-xs text-muted md:inline">{{ variantUsage(profile.key, variant.key) }}</span>
                </div>
                <div class="flex shrink-0 items-center gap-5 text-muted">
                  <span class="tabular-nums">{{ variantSizeLabel(variant) }}</span>
                  <span class="hidden sm:inline">{{ variant.format.toUpperCase() }}</span>
                  <span class="hidden sm:inline">{{ variantModeLabel(variant.mode) }}</span>
                </div>
              </div>
            </div>
            <p v-else class="mt-4 text-sm text-muted">未配置交付规格</p>
          </article>
        </div>
      </section>

      <form v-else class="min-w-0 max-w-full" data-asset-registration-editor @submit.prevent="save">
        <section class="yueli-card min-w-0" data-manage-surface="asset">
          <div class="px-3 pt-3 sm:px-4 sm:pt-4">
            <UTabs
              v-model="activeProfileKey"
              :items="profileTabs"
              :content="false"
              variant="link"
              class="w-full"
              :ui="{ list: 'min-w-0', trigger: 'min-w-max' }"
              aria-label="资源用途"
            />
          </div>

          <div v-if="activeProfile" :data-asset-profile-editor="activeProfile.key" class="min-w-0 p-4 sm:p-5">
            <section>
              <h3 class="text-sm font-semibold text-highlighted">上传限制</h3>
              <div class="mt-3 grid max-w-3xl gap-4 sm:grid-cols-2">
                <UFormField name="storageBackend" label="存储后端" class="min-w-0">
                  <USelect
                    v-model="activeProfile.storageBackend"
                    :items="storageBackendItems(activeProfile.key)"
                    value-key="value"
                    class="w-full"
                    :disabled="storageBackendItems(activeProfile.key).length <= 1"
                    data-asset-storage-backend
                  />
                </UFormField>
                <UFormField name="maxSizeMB" label="大小上限（MB）" class="min-w-0">
                  <UInputNumber v-model="activeProfile.maxSizeMB" :min="1" :step="1" class="min-w-0 w-full" />
                </UFormField>
              </div>
              <p class="mt-3 text-xs text-muted">
                {{ mimeLabel(activeProfile.allowedMimes) }} ·
                {{ activeProfile.metadataPolicy === 'strip' ? '清理元数据' : '保留元数据' }} ·
                {{ activeProfile.keepOriginal ? '保留处理后源文件' : '仅保留派生文件' }}
              </p>
            </section>

            <section v-if="isImageProfile(activeProfile)" class="mt-6 min-w-0 border-t border-default pt-5">
              <div class="flex items-center gap-2">
                <div class="flex items-center gap-2">
                  <h3 class="text-sm font-semibold text-highlighted">交付规格</h3>
                  <span class="text-xs text-muted">{{ activeProfile.variants.length }} 个</span>
                </div>
              </div>

              <div v-if="activeProfile.variants.length" class="mt-3 divide-y divide-default border-y border-default">
                <div
                  v-for="variant in activeProfile.variants"
                  :key="variant.key"
                  :data-asset-variant-key="variant.key"
                  class="grid min-w-0 gap-3 py-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"
                  data-asset-variant-editor
                >
                  <div class="min-w-0">
                    <div class="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
                      <span class="font-medium text-default">{{ variantDisplayName(activeProfile.key, variant.key) }}</span>
                      <span class="text-xs text-muted">· {{ variant.key }}</span>
                    </div>
                    <p class="mt-0.5 text-xs text-muted">{{ variantUsage(activeProfile.key, variant.key) }}</p>
                    <p class="mt-1 text-sm text-muted">
                      <span>{{ variantSizeLabel(variant) }}</span> · {{ variant.format.toUpperCase() }} ·
                      {{ variantModeLabel(variant.mode) }} · 质量 {{ variant.quality }}
                    </p>
                  </div>
                  <div v-if="presetItems(activeProfile.key, variant).length > 1" class="sm:w-56">
                    <UFormField :name="`preset-${variant.key}`" label="预设">
                      <USelect
                        :model-value="selectedPreset(activeProfile.key, variant)"
                        :items="presetItems(activeProfile.key, variant)"
                        value-key="value"
                        class="w-full"
                        :aria-label="`${variantDisplayName(activeProfile.key, variant.key)}预设`"
                        @update:model-value="applyPreset(activeProfile.key, variant, $event)"
                      />
                    </UFormField>
                  </div>
                  <span v-else class="text-xs text-muted sm:justify-self-end">固定预设</span>
                </div>
              </div>
              <p v-else class="mt-4 py-6 text-center text-sm text-muted">尚未配置交付规格</p>
            </section>
          </div>
        </section>
      </form>
    </div>
  </div>
</template>
