<script setup lang="ts">
import { ref, watch } from "vue";
import { parseNumericRange, type NumericRange } from "../numeric-range";
const props = defineProps<{
  modelValue: NumericRange;
  label: string;
  unit?: string;
  floor?: number;
  integer?: boolean;
}>();
const emit = defineEmits<{
  "update:modelValue": [value: NumericRange];
  apply: [value: NumericRange];
}>();
const lower = ref("");
const upper = ref("");
const error = ref("");
watch(
  () => props.modelValue,
  (value) => {
    lower.value = value.min === undefined ? "" : String(value.min);
    upper.value = value.max === undefined ? "" : String(value.max);
  },
  { immediate: true, deep: true },
);
function apply() {
  try {
    const value = parseNumericRange(lower.value, upper.value, props);
    error.value = "";
    emit("update:modelValue", value);
    emit("apply", value);
  } catch (reason) {
    error.value = reason instanceof Error ? reason.message : "请输入有效范围";
  }
}
function clear() {
  lower.value = "";
  upper.value = "";
  apply();
}
</script>
<template>
  <form
    class="grid min-w-0 gap-2"
    :aria-label="`${label}区间`"
    @submit.prevent="apply"
  >
    <strong class="text-xs font-semibold text-highlighted"
      >{{ label
      }}<span v-if="unit" class="font-normal text-muted"
        >（{{ unit }}）</span
      ></strong
    >
    <div class="flex min-w-0 items-center gap-2">
      <UInput
        :model-value="lower"
        type="number"
        @update:model-value="lower = String($event ?? '')"
        :step="integer ? 1 : 'any'"
        :min="floor"
        :aria-label="`${label}下限`"
        placeholder="不限"
        class="min-w-0 flex-1"
      />
      <span class="text-muted" aria-hidden="true">~</span>
      <UInput
        :model-value="upper"
        type="number"
        @update:model-value="upper = String($event ?? '')"
        :step="integer ? 1 : 'any'"
        :min="floor"
        :aria-label="`${label}上限`"
        placeholder="不限"
        class="min-w-0 flex-1"
      />
    </div>
    <p v-if="error" role="alert" class="text-xs text-error">{{ error }}</p>
    <div class="flex gap-2">
      <UButton
        type="submit"
        label="应用区间"
        size="xs"
        variant="soft"
      /><UButton
        v-if="lower || upper"
        label="清除区间"
        size="xs"
        color="neutral"
        variant="ghost"
        @click="clear"
      />
    </div>
  </form>
</template>
