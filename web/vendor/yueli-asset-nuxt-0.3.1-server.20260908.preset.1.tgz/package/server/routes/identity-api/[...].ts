import { createBffHandler } from "@yueli/nuxt-runtime/server";

export default createBffHandler({
  mountPath: "/identity-api",
  timeoutMs: 15_000,
  maxRequestBodyBytes: 1024 * 1024,
  resolveTarget({ event }) {
    return assetBffTarget(String(useRuntimeConfig(event).identityBase));
  },
  credential: {
    async resolve({ event }) {
      return assetBffCredential(await sessionAuthHeaders(event));
    },
  },
});
