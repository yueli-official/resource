<script setup lang="ts">
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
} from "vue";

export interface AdminTabItem {
  label: string;
  value: string;
  icon?: string;
  badge?: string | number;
  disabled?: boolean;
}

const active = defineModel<string>({ required: true });
const props = defineProps<{
  items: readonly AdminTabItem[];
  navigationLabel: string;
}>();
const items = computed(() => [...props.items]);
const navigation = ref<HTMLElement>();
let observer: ResizeObserver | undefined;

async function revealActive() {
  await nextTick();
  const container = navigation.value;
  const selected = container?.querySelector<HTMLElement>(
    '[role="tab"][aria-selected="true"]',
  );
  if (!container || !selected) return;
  const bounds = container.getBoundingClientRect();
  const item = selected.getBoundingClientRect();
  const left = bounds.left + container.clientLeft;
  const right = left + container.clientWidth;
  const delta =
    item.left < left
      ? item.left - left
      : item.right > right
        ? item.right - right
        : 0;
  if (delta) container.scrollBy({ left: delta, behavior: "instant" });
}

watch([active, items], revealActive, { deep: true });
onMounted(() => {
  revealActive();
  if (typeof ResizeObserver !== "undefined" && navigation.value) {
    observer = new ResizeObserver(revealActive);
    observer.observe(navigation.value);
  }
});
onBeforeUnmount(() => observer?.disconnect());
</script>

<template>
  <nav
    ref="navigation"
    :aria-label="navigationLabel"
    class="yueli-admin-tabs min-w-0 overflow-x-auto overflow-y-hidden px-2 sm:px-4"
    data-admin-tabs
  >
    <UTabs
      :model-value="active"
      :items="items"
      :content="false"
      variant="link"
      class="w-max min-w-full"
      :ui="{
        list: 'min-w-max border-0 mb-0',
        trigger: 'min-w-max px-4 py-3.5 data-[state=active]:font-semibold',
        indicator: 'bottom-0 h-0.5 rounded-full bg-primary',
      }"
      :aria-label="navigationLabel"
      @update:model-value="active = String($event)"
    />
  </nav>
</template>

<style scoped>
/* Outside the utility layer so the global native scrollbar theme cannot win. */
.yueli-admin-tabs {
  scrollbar-width: none;
}
.yueli-admin-tabs::-webkit-scrollbar {
  display: none;
}
</style>
