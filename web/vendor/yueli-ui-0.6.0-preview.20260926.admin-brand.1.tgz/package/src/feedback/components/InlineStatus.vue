<script setup lang="ts">
import { computed } from "vue";
import type { FeedbackTone } from "../notice";

const props = withDefaults(
  defineProps<{
    tone?: FeedbackTone;
    title?: string;
    icon?: string;
    dismissible?: boolean;
    dismissLabel?: string;
  }>(),
  {
    tone: "neutral",
    title: "",
    icon: "",
    dismissible: false,
    dismissLabel: "Close",
  },
);

defineEmits<{ dismiss: [] }>();

const toneClass = computed(() => {
  if (props.tone === "error") return "text-error";
  if (props.tone === "warning") return "text-warning";
  if (props.tone === "success") return "text-success";
  if (props.tone === "info") return "text-info";
  return "text-muted";
});

const defaultIcon = computed(() => {
  if (props.tone === "error") return "i-tabler-alert-circle";
  if (props.tone === "warning") return "i-tabler-alert-triangle";
  if (props.tone === "success") return "i-tabler-circle-check";
  return "i-tabler-info-circle";
});
</script>

<template>
  <div
    class="flex min-w-0 items-start gap-1.5 text-xs leading-5"
    :class="toneClass"
    :role="tone === 'error' ? 'alert' : 'status'"
  >
    <UIcon :name="icon || defaultIcon" class="mt-0.5 size-3.5 shrink-0" />
    <div class="min-w-0 flex-1 break-words">
      <span v-if="title" class="font-medium">{{ title }}</span>
      <span :class="title ? 'ml-1 text-muted' : ''"><slot /></span>
    </div>
    <div v-if="$slots.actions" class="flex shrink-0 items-center gap-1.5">
      <slot name="actions" />
    </div>
    <UButton
      v-if="dismissible"
      size="xs"
      color="neutral"
      variant="link"
      icon="i-tabler-x"
      class="-my-1 shrink-0"
      :aria-label="dismissLabel"
      @click="$emit('dismiss')"
    />
  </div>
</template>
