import {
  useApi as useFoundationApi,
} from "@yueli/nuxt-runtime/runtime";
import type {
  HttpMethod,
  QueryValue,
  RequestOptions,
} from "@yueli/http-runtime";

export interface AssetApiCallOptions {
  readonly method?: string;
  readonly query?: Readonly<Record<string, QueryValue>>;
  readonly body?: unknown;
  readonly headers?: HeadersInit;
  readonly signal?: AbortSignal;
  readonly timeout?: number;
}

function queryFromUrl(search: string) {
  const query: Record<string, string | string[]> = {};
  for (const [name, value] of new URLSearchParams(search)) {
    const current = query[name];
    if (current === undefined) query[name] = value;
    else if (Array.isArray(current)) query[name] = [...current, value];
    else query[name] = [current, value];
  }
  return query;
}

function prepareAssetRequest<T>(
  url: string,
  options: AssetApiCallOptions = {},
): { path: `/${string}`; options: RequestOptions<T> } {
  if (!url.startsWith("/") || url.includes("#"))
    throw new Error("asset.request.invalid_path");
  const queryIndex = url.indexOf("?");
  const path = (queryIndex === -1 ? url : url.slice(0, queryIndex)) as `/${string}`;
  const search = queryIndex === -1 ? "" : url.slice(queryIndex + 1);
  const headers = options.headers
    ? (Object.fromEntries(
        new Headers(options.headers),
      ) as RequestOptions<T>["headers"])
    : undefined;
  return {
    path,
    options: {
      method: String(options.method ?? "GET").toUpperCase() as HttpMethod,
      query: { ...queryFromUrl(search), ...options.query },
      body: options.body as RequestOptions<T>["body"],
      headers,
      signal: options.signal,
      timeoutMs: options.timeout,
    },
  };
}

export function useAssetRuntimeApi(target: "asset" | "identity") {
  const request = useFoundationApi(target);
  return {
    request,
    async call<T>(
      url: string,
      options?: AssetApiCallOptions,
    ): Promise<T> {
      const prepared = prepareAssetRequest<T>(url, options);
      return request.request(prepared.path, prepared.options);
    },
  };
}
